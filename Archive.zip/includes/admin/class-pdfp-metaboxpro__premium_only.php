<?php

namespace PDFPro\Admin;

use PDFPro\Api\PDFP_DropboxApi;
use PDFPro\Api\PDFP_GoogleDriveApi;
use PDFPro\Helper\PDFP_Functions as Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'PDFPro\Admin\PDFP_MetaBoxPro' ) ) {
    class PDFP_MetaBoxPro {
        private $metabox_prefix = '_fpdf';
        private $option = null;

        public function register() {
            add_action('init', array($this, 'register_metabox'), 0);
        }

        public function register_metabox() {
            if (class_exists('\CSF')) {
                \CSF::createMetabox($this->metabox_prefix, array(
                    'title' => __('PDF Poster Configuration', 'pdfp'),
                    'post_type' => 'pdfposter',
                    'theme' => 'light'
                ));

                if (!pdfp_fs()->can_use_premium_code()) {
                    Utils::pipeError($this->metabox_prefix);
                } else {
                    $this->configure();
                    $this->controls();
                    $this->actions();
                    $this->popup();
                    $this->protect_content();
                    $this->social_share();
                    $this->styles();
                    $this->ads();
                    $this->analytics();
                }
            }
        }

        public function configure() {
            if (!$this->option) {
                $this->option = get_option('fpdf_option');
            }

            new PDFP_DropboxApi(Utils::isset($this->option, 'dropbox_app_key'));

            new PDFP_GoogleDriveApi(Utils::isset($this->option, 'google_apikey'), Utils::isset($this->option, 'google_client_id'), Utils::isset($this->option, 'google_project_number'));

            \CSF::createSection($this->metabox_prefix, array(
                'title'  => 'General',
                'fields' => array(
                    array(
                        'id' => 'viewer',
                        'type' => 'button_set',
                        'title' => __('Viewer', 'pdfp'),
                        'desc' => __('Select the PDF viewer engine.', 'pdfp'),
                        'default' => 'default',
                        'options' => array(
                            'default' => __('Default', 'pdfp'),
                            'adobe' => __('Adobe', 'pdfp'),
                            'flipbook' => __('FlipBook', 'pdfp') . Utils::pdfp_new_badge(),
                        )
                    ),
                    array(
                        'id'    => 'source',
                        'type'  => 'upload',
                        'title' => __('PDF Source', 'pdfp'),
                        'desc'  => __('Select or upload your PDF file.', 'pdfp'),
                        'attributes' => array('id' => 'picker_field')
                    ),
                    array(
                        'id' => 'dropbox_button',
                        'title' => ' ',
                        'type' => 'content',
                        'content' => '<div id="picker_container"></div>',
                        'dependency' => array(
                            array('viewer', '!=', 'adobe')
                        )
                    ),
                    array(
                        'id' => 'device_preview',
                        'type' => 'button_set',
                        'title' =>  __('Preview Device', 'pdfp'). Utils::pdfp_new_badge(),
                        'options' => array(
                            'desktop' => __('Desktop', 'pdfp'),
                            'tablet' => __('Tablet', 'pdfp'),
                            'mobile' => __('Mobile', 'pdfp'),
                        ),
                        'default' => 'desktop',
                    ),
                    array(
                        'id' => 'height',
                        'title' => __('Height (Desktop)', 'pdfp'),
                        'type' => 'dimensions',
                        'width' => false,
                        'desc'  => __('Set the height of the viewer for desktop.', 'pdfp'),
                        'units' => ['px', '%', 'em', 'vh'],
                        'default' => Utils::pdfp_preset('preset_height', [
                            'height' => 842,
                            'unit' => 'px'
                        ]),
                        'dependency' => array('device_preview', '==', 'desktop')
                    ),
                    array(
                        'id' => 'height_tablet',
                        'title' => __('Height (Tablet)', 'pdfp'),
                        'type' => 'dimensions',
                        'width' => false,
                        'desc'  => __('Set the height of the viewer for tablet.', 'pdfp'),
                        'units' => ['px', '%', 'em', 'vh'],
                        'default' => [
                            'height' => 700,
                            'unit' => 'px'
                        ],
                        'dependency' => array('device_preview', '==', 'tablet')
                    ),
                    array(
                        'id' => 'height_mobile',
                        'title' => __('Height (Mobile)', 'pdfp'),
                        'type' => 'dimensions',
                        'width' => false,
                        'desc'  => __('Set the height of the viewer for mobile.', 'pdfp'),
                        'units' => ['px', '%', 'em', 'vh'],
                        'default' => [
                            'height' => 400,
                            'unit' => 'px'
                        ],
                        'dependency' => array('device_preview', '==', 'mobile')
                    ),
                    array(
                        'id' => 'width',
                        'title' => __('Width (Desktop)', 'pdfp'),
                        'type' => 'dimensions',
                        'height' => false,
                        'desc'  => __('Set the width of the viewer for desktop.', 'pdfp'),
                        'units' => ['px', '%', 'em', 'vh'],
                        'default' => Utils::pdfp_preset('preset_width', [
                            'width' => '100',
                            'unit' => '%'
                        ]),
                        'dependency' => array('device_preview', '==', 'desktop')
                    ),
                    array(
                        'id' => 'width_tablet',
                        'title' => __('Width (Tablet)', 'pdfp'),
                        'type' => 'dimensions',
                        'height' => false,
                        'desc'  => __('Set the width of the viewer for tablet.', 'pdfp'),
                        'units' => ['px', '%', 'em', 'vh'],
                        'default' => [
                            'width' => '100',
                            'unit' => '%'
                        ],
                        'dependency' => array('device_preview', '==', 'tablet')
                    ),
                    array(
                        'id' => 'width_mobile',
                        'title' => __('Width (Mobile)', 'pdfp'),
                        'type' => 'dimensions',
                        'height' => false,
                        'desc'  => __('Set the width of the viewer for mobile.', 'pdfp'),
                        'units' => ['px', '%', 'em', 'vh'],
                        'default' => [
                            'width' => '100',
                            'unit' => '%'
                        ],
                        'dependency' => array('device_preview', '==', 'mobile')
                    ),
                    array(
                        'id' => 'default_browser',
                        'title' => __('Google Doc Viewer', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_default_browser'),
                        'desc' => __('Enable Google Doc Viewer as a fallback (Recommended for Edge).', 'pdfp'),
                        'subtitle' => 'only work on Microsoft Edge browser',
                    )				
                )
            ));
        }

        public function controls(){
            \CSF::createSection($this->metabox_prefix, array(
                'title' => __('Controls', 'pdfp'),
                'fields' => array(
                    array(
                        'id' => 'show_filename',
                        'title' => __('Display Filename', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_show_filename', true),
                        'desc' => __('Show the filename at the top of the viewer.', 'pdfp')
                    ),
                    array(
                        'id' => 'only_pdf',
                        'title' => __('Reader Mode', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_only_pdf'),
                        'desc' => __('Hide the PDF menu and background for a minimalist look.', 'pdfp')
                    ),
                    array(
                        'id' => 'thumbnail_toggle_menu',
                        'title' => __('Toggle Thumbnails', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_thumbnail_toggle_menu', true),
                        'desc' => __('Enable thumbnail navigation in the viewer.', 'pdfp')
                    ),
                    array(
                        'id' => 'sidebar_open',
                        'title' => __('Sidebar Open', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_sidebar_open', false),
                        'desc' => __('Open the thumbnail sidebar by default.', 'pdfp')
                    ),
                    array(
                        'id' => 'ppv_load_last_version',
                        'title' => __('Load Latest Version', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_ppv_load_last_version', false),
                        'desc' => __('Automatically load the most recent version of the PDF.', 'pdfp')
                    ),
                    array(
                        'id' => 'hr_scroll',
                        'title' => __('Horizontal Scrollbar', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_hr_scroll', false),
                        'desc' => esc_html__('Enable horizontal scrolling for wide documents.', 'pdfp'),
                        'dependency' => array('viewer', '!=', 'flipbook')
                    ),
                    array(
                        'id' => 'jump_to',
                        'title' => __('Initial Page', 'pdfp'),
                        'type' => 'number',
                        'desc' => esc_html__('Set the page number displayed when the viewer loads.', 'pdfp'),
                        'default' => 1
                    ),
                    array(
                        'id' => 'zoomLevel',
                        'title' => esc_html__('Default Zoom', 'pdfp'),
                        'type' => 'number',
                        'desc' => esc_html__('Set the initial zoom level (leave empty for auto).', 'pdfp'),
                        'default' => '',
                        'unit' => '%',
                        'dependency' => array('viewer', '!=', 'flipbook')
                    )
                )
            ));
        }

        public function actions(){
            \CSF::createSection($this->metabox_prefix, array(
                'title' => __('Actions', 'pdfp'),
                'fields' => array(
                    array(
                        'id' => 'print',
                        'title' => __('Allow Printing', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_print'),
                        'desc' => __('Allow visitors to print the PDF document.', 'pdfp')
                    ),
                    array(
                        'id' => 'show_download_btn',
                        'title' => __('Download Button', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_show_download_btn', true),
                        'desc' => __('Display a download button at the top of the viewer.', 'pdfp')
                    ),
                    array(
                        'id' => 'download_btn_text',
                        'title' => __('Download Label', 'pdfp'),
                        'type' => 'text',
                        'desc' => __('Customize the text for the download button.', 'pdfp'),
                        'default' => Utils::pdfp_preset('preset_download_btn_text', 'Download File'),
                        'dependency' => array('show_download_btn', '==', '1')
                    ),
                    array(
                        'id' => 'view_fullscreen_btn',
                        'title' => __('Fullscreen Button', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_view_fullscreen_btn', 0),
                        'desc' => __('Display a fullscreen toggle button at the top of the viewer.', 'pdfp')
                    ),
                    array(
                        'id' => 'fullscreen_btn_text',
                        'title' => __('Fullscreen Label', 'pdfp'),
                        'type' => 'text',
                        'desc' => __('Customize the text for the fullscreen button.', 'pdfp'),
                        'default' => Utils::pdfp_preset('preset_fullscreen_btn_text', 'View Fullscreen'),
                        'dependency' => array('view_fullscreen_btn', '==', '1')
                    ),
                    array(
                        'id' => 'view_fullscreen_btn_target_blank',
                        'title' => __('Open in New Tab', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_view_fullscreen_btn_target_blank', false),
                        'desc' => __('Open the fullscreen view in a new browser tab.', 'pdfp'),
                        'dependency' => array(
                            array('view_fullscreen_btn', '==', '1'),
                            array('viewer', '!=', 'flipbook')
                        )
                    ),
                    array(
                        'id' => 'actions_position',
                        'title' => __('Actions Position', 'pdfp'),
                        'type' => 'button_set',
                        'options' => array(
                            'top' => __('Top', 'pdfp'),
                            'bottom' => __('Bottom', 'pdfp'),
                        ),
                        'default' => 'top',
                        'desc' => __('Select where the action buttons should appear.', 'pdfp'),
                    ),
                )
            ));
        }


        public function popup(){
            \CSF::createSection($this->metabox_prefix, array(
                'title' => __('Popup', 'pdfp'),
                'fields' => array(
                    array(
                        'id' => 'popup',
                        'title' => __('Enable Popup', 'pdfp'),
                        'type' => 'switcher',
                        'desc' => __('Open the PDF document in a modal popup.', 'pdfp'),
                        'default' => false,
                    ),
                    array(
                        'id' => 'popup_trigger_type',
                        'title' => __('Trigger Type', 'pdfp'),
                        'type' => 'button_set',
                        'options' => array(
                            'button' => __('Button', 'pdfp'),
                            'image' => __('Image', 'pdfp'),
                        ),
                        'default' => 'button',
                        'desc' => __('Select the trigger type for the popup.', 'pdfp'),
                        'dependency' => array('popup', '==', '1')
                    ),
                    array(
                        'id' => 'popup_trigger_alignment',
                        'title' => __('Alignment', 'pdfp'),
                        'type' => 'button_set',
                        'options' => array(
                            'left' => __('Left', 'pdfp'),
                            'center' => __('Center', 'pdfp'),
                            'right' => __('Right', 'pdfp'),
                        ),
                        'default' => 'center',
                        'desc' => __('Select the alignment for the popup trigger.', 'pdfp'),
                        'dependency' => array('popup', '==', '1')
                    ),
                    array(
                        'id' => 'popup_image',
                        'title' => __('Image', 'pdfp'),
                        'type' => 'media',
                        'library' => 'image',
                        'desc' => __('Select an image to use as the popup trigger.', 'pdfp'),
                        'dependency' => array('popup_trigger_type|popup', '==|==', 'image|1')
                    ),
                    array(
                        'id' => 'popup_btn_text',
                        'title'   => __('Button Text', 'pdfp'),
                        'type'    => 'text',
                        'desc'    => __('Customize the text for the popup trigger button.', 'pdfp'),
                        'default' => 'Open PDF',
                        'dependency' => array('popup_trigger_type|popup', '==|==', 'button|1')
                    ),
                    array(
                        'id' => 'popup_image_height',
                        'title' => __('Image Height', 'pdfp'),
                        'type' => 'dimensions',
                        'width' => false,
                        'desc' => __('Set the height for the trigger image.', 'pdfp'),
                        'units' => ['px', '%', 'em', 'vh'],
                        'default' => [
                            'height' => 200,
                            'unit' => 'px'
                        ],
                        'dependency' => array('popup_trigger_type|popup', '==|==', 'image|1')
                    ),
                    array(
                        'id' => 'popup_image_width',
                        'title' => __('Image Width', 'pdfp'),
                        'type' => 'dimensions',
                        'height' => false,
                        'desc' => __('Set the width for the trigger image.', 'pdfp'),
                        'units' => ['px', '%', 'em', 'vh'],
                        'default' =>  [
                            'width' => '300',
                            'unit' => 'px'
                        ],
                        'dependency' => array('popup_trigger_type|popup', '==|==', 'image|1')
                    ),
                    array(
                        'id' => 'popup_image_pdf_icon',
                        'title' => __('Enable PDF Icon', 'pdfp'),
                        'type' => 'switcher',
                        'desc' => __('Show a PDF icon over the trigger image.', 'pdfp'),
                        'default' => true,
                        'dependency' => array('popup_trigger_type|popup', '==|==', 'image|1')
                    ),


                ),
            ));
        }

        public function protect_content(){
            \CSF::createSection($this->metabox_prefix, array(
                'title' => __('Protect Content', 'pdfp'),
                'fields' => array(
                    array(
                        'id' => 'protect',
                        'title' => __('Protect Content', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_protect', 0),
                        'desc' => __('Disable right-click and text selection to protect your content.', 'pdfp')
                    ),
                    array(
                        'id' => 'disable_alert',
                        'title' => __('Disable Alert', 'pdfp'),
                        'type' => 'switcher',
                        'default' => Utils::pdfp_preset('preset_disable_alert', true),
                        'desc' => __('Suppress the warning message when right-click is blocked.', 'pdfp'),
                        'dependency' => array('protect', '==', '1')
                    ),
                )
            ));
        }

        public function social_share(){
            \CSF::createSection($this->metabox_prefix, array(
                'title' => __('Social Share', 'pdfp'),
                'fields' => array(
                    array(
                        'id' => 'social_share',
                        'title' => __('Enable Sharing', 'pdfp'),
                        'type' => 'switcher',
                        'desc' => esc_html__('Enable social sharing buttons for the PDF.', 'pdfp'),
                        'default' => false,
                    ),
                    array(
                        'id' => 'social_share_position',
                        'title' => __('Share Position', 'pdfp'),
                        'type' => 'select',
                        'desc' => esc_html__('Select where the sharing buttons should appear.', 'pdfp'),
                        'default' => 'top',
                        'options' => array(
                            'top' => esc_html__('Top', 'pdfp'),
                            'bottom' => esc_html__('Bottom', 'pdfp'),
                        ),
                        'dependency' => array('social_share', '==', '1')
                    ),
                    array(
                        'id' => 'social_share_facebook',
                        'title' => __('Enable Facebook', 'pdfp'),
                        'type' => 'switcher',
                        'desc' => esc_html__('Allow sharing on Facebook.', 'pdfp'),
                        'default' => true,
                        'dependency' => array('social_share', '==', '1')
                    ),
                    array(
                        'id' => 'social_share_twitter',
                        'title' => __('Enable Twitter', 'pdfp'),
                        'type' => 'switcher',
                        'desc' => esc_html__('Allow sharing on Twitter.', 'pdfp'),
                        'default' => true,
                        'dependency' => array('social_share', '==', '1')
                    ),
                    array(
                        'id' => 'social_share_linkedin',
                        'title' => __('Enable LinkedIn', 'pdfp'),
                        'type' => 'switcher',
                        'desc' => esc_html__('Allow sharing on LinkedIn.', 'pdfp'),
                        'default' => true,
                        'dependency' => array('social_share', '==', '1')
                    ),
                    array(
                        'id' => 'social_share_pinterest',
                        'title' => __('Enable Pinterest', 'pdfp'),
                        'type' => 'switcher',
                        'desc' => esc_html__('Allow sharing on Pinterest.', 'pdfp'),
                        'default' => true,
                        'dependency' => array('social_share', '==', '1')
                    ),
                )
            ));
        }

        public function styles(){
            \CSF::createSection($this->metabox_prefix, array(
                'title' => __('Styles', 'pdfp'),
                'fields' => array(
                    array(
                        'id'      => 'popup_btn_bg',
                        'title'   => __('Button Background', 'pdfp'),
                        'type'    => 'color',
                        'desc'    => __('Choose a background color for the buttons.', 'pdfp'),
                        'default' => '#1e73be',
                    ),
                    array(
                        'id'      => 'popup_btn_color',
                        'title'   => __('Button Color', 'pdfp'),
                        'type'    => 'color',
                        'desc'    => __('Choose a text color for the buttons.', 'pdfp'),
                        'default' => '#fff'
                    ),
                    array(
                        'id'      => 'popup_btn_font_size',
                        'title'   => __('Font Size', 'pdfp'),
                        'type'    => 'number',
                        'desc'    => esc_html__('Set the font size for the buttons.', 'pdfp'),
                        'default' => 1,
                        'unit' => 'rem'
                    ),
                    array(
                        'id'      => 'popup_btn_padding',
                        'title'   => __('Padding', 'pdfp'),
                        'type'    => 'spacing',
                        'desc'    => __('Set the internal spacing for the buttons.', 'pdfp'),
                        'default' => [
                            'top'    => '10',
                            'bottom'    => '10',
                            'left'    => '20',
                            'right'    => '20',
                        ],
                        'units' => array('px')
                    ),
                ),
            ));
        }

        public function ads(){
            \CSF::createSection($this->metabox_prefix, array(
                'title' => Utils::pdfp_pro_title(__('Ads', 'pdfp'), "Upcoming"),
                'fields' => array(
                    Utils::upcoming_section()
                )
            ));
        }

        public function analytics(){
            \CSF::createSection($this->metabox_prefix, array(
                'title' => Utils::pdfp_pro_title(__('Analytics', 'pdfp'), "Upcoming"),
                'fields' => array(
                    Utils::upcoming_section()
                )
            ));
        }

    }
}
