<?php
namespace PDFPro\Api;

use PDFPro\Api\DropboxApi;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'PDFPro\Api\PDFP_Dropbox' ) ) {
    class PDFP_Dropbox{

    private $fieldId = null;
    private $appKey = null;

    public function register(){
        $dropbox = new PDFP_DropboxApi('m4f8cgysa55edg8');
    }
}
}