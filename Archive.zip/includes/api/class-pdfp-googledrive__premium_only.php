<?php
namespace PDFPro\Api;

use PDFPro\Api\GoogleDriveApi;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'PDFPro\Api\PDFP_GoogleDrive' ) ) {
    class PDFP_GoogleDrive{

    private $fieldId = null;
    private $appKey = null;

    public function register(){
        $drive = new PDFP_GoogleDriveApi('AIzaSyDgt4FzilM45vpspyL9SfOZeOxGIx2GiRo', '282957762539-4oiur3kgqnme1650uf7n1npe20mn5r9p.apps.googleusercontent.com', '282957762539');
    }
}
}