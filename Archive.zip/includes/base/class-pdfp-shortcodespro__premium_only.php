<?php

namespace PDFPro\Base;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'PDFPro\Base\PDFP_ShortcodesPro' ) ) {
    class PDFP_ShortcodesPro extends PDFP_Shortcodes
{

  public function register()
  {
    add_shortcode('pdf', [$this, 'pdf'], 10, 2);
    add_shortcode('raw_pdf', [$this, 'raw_pdf']);
    add_shortcode('pdf_embed', [$this, 'pdf_embed']);
  }

  public function pdf_embed_attrs()
  {
    return [
      'url' => null,
      'width' => null,
      'height' => null,
      'print' => null,
      'title' => null,
      'download_btn' => null,
      'fullscreen_btn' => null,
      'fullscreen_btn_text' => null,
      'download_btn_text' => null,
      "align" => "none",
      "alignment" => "left",
      "only_pdf" => "false",
      "protect" => null,
      "thumb_menu" => null,
      "initial_page" => 1,
      "hr_scroll" => 'false',
      "adobe" => 'false',
      "class" => '',
      "new_window" => null,
      "popup" => null,
      "popup_btn_text" => 'Open PDF',
      "popup_btn_bg" => null,
      "popup_btn_color" => null,
      "popup_btn_font_size" => null,
      "popup_btn_padding" => '10px 20px',
    ];
  }

  public function pdf_embed_to_block($attrs)
  {
    extract($attrs);

    if(!function_exists('pdfp_get_option')) {
      return [
        'blockName' => 'pdfp/pdfposter',
      ];
    }

    $settings = pdfp_get_option('fpdf_option');

    return [
      "blockName" => "pdfp/pdfposter",
      "attrs" => [
        'uniqueId' => wp_unique_id('pdfp'),
        'file' => esc_url($url),
        'title' => $title ? esc_html($title) : basename($url),
        'height' => $height ? esc_html($height) : $settings('height', ['height' => '100'], false)['height'] . $settings('height', ['unit' => '%'], false)['unit'],
        'width' => $width ? esc_html($width) : $settings('width', ['width' => '100'], false)['width'] . $settings('width', ['unit' => '%'], false)['unit'],
        'print' => $print ? $print : $settings('print', false, true),
        'downloadButton' => $download_btn ? $download_btn === 'true' : $settings('show_download_btn', false, true),
        'fullscreenButtonText' => $fullscreen_btn_text ? esc_html($fullscreen_btn_text) : $settings('fullscreen_btn_text', 'View Fullscreen'),
        'fullscreenButton' => $fullscreen_btn ? $fullscreen_btn === 'true' : $settings('view_fullscreen_btn', false, true),
        'newWindow' => $new_window ? $new_window === 'true'  : $settings('view_fullscreen_btn_target_blank', false, true),
        'showName' => $settings('show_filename', false, true),
        'downloadButtonText' => $download_btn_text ? esc_html($download_btn_text) : $settings('download_btn_text', 'Download'),
        'alignment' => esc_html($alignment),
        'protect' => $protect ? $protect === 'true' : $settings('protect', false, true),
        'onlyPDF' => $only_pdf === 'true',
        'defaultBrowser' => $settings('default_browser', false, true),
        'thumbMenu' => $thumb_menu ? $thumb_menu === 'true' : $settings('thumbnail_toggle_menu', false, true),
        'initialPage' => (int) $initial_page,
        'sidebarOpen' => false,
        'lastVersion' => false,
        'hrScroll' => $hr_scroll === 'true',
        'zoomLevel' => null,
        'alert' => ! $settings('disable_alert', false, true),
        'adobeEmbedder' => in_array($adobe, ['adobe', 'flipbook', 'default']) ? $adobe : ($adobe === 'true' ? 'adobe' : 'default'),
        'btnStyles' => [
          "background" =>  $popup_btn_bg,
          "color" =>  $popup_btn_color,
          "fontSize" =>  $popup_btn_font_size,
          "padding" =>  $popup_btn_padding
        ],
        "popupOptions" => [
          "enabled" =>  $popup === 'true',
          "text" =>  $popup_btn_text,
          "btnStyle" =>  [
            "background" =>  $popup_btn_bg,
            "color" =>  $popup_btn_color,
            "fontSize" =>  $popup_btn_font_size,
            "padding" =>  $popup_btn_padding
          ]
        ],
        
        'additional' => [
          'class' => esc_html($class)
        ],
      ]

    ];
  }
}

}